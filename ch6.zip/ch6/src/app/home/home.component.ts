import { Component, OnInit } from '@angular/core';
import { Routes } from '@angular/router';
import { SformComponent } from '../sform/sform.component';
import { LoginFormComponent } from '../login-form/login-form.component';
import { StudentComponent } from '../student/student.component';

export const childRoutes: Routes = [
  { path: '', component: StudentComponent },
  { path: 'select', component: SformComponent },
  { path: 'stable', component: StudentComponent },
  { path: 'exit', component: LoginFormComponent }
];

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  menuindex = 2;
  constructor() {
  }

  ngOnInit() {
  }
  menu(index) {
    this.menuindex = index;
  }

}
